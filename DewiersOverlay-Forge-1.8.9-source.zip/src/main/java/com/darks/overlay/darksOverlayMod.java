package com.darks.overlay;

import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.AxisAlignedBB;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@Mod(
    modid = darksOverlayMod.MODID,
    name = "darks Overlay",
    version = darksOverlayMod.VERSION,
    clientSideOnly = true
)
public class darksOverlayMod {
    public static final String MODID = "darksoverlay";
    public static final String VERSION = "1.0.0";

    // Profile value: 0x72000000 = ARGB(114, 0, 0, 0)
    private static final float OVERLAY_ALPHA = 114.0F / 255.0F;

    @Mod.EventHandler
    public void init(FMLInitializationEvent event) {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onDrawBlockHighlight(DrawBlockHighlightEvent event) {
        if (event.target == null || event.target.typeOfHit != net.minecraft.util.MovingObjectPosition.MovingObjectType.BLOCK) {
            return;
        }

        // Cancel vanilla's selection outline.
        event.setCanceled(true);

        Minecraft mc = Minecraft.getMinecraft();
        if (mc.theWorld == null) {
            return;
        }

        AxisAlignedBB box = mc.theWorld
            .getBlockState(event.target.getBlockPos())
            .getBlock()
            .getSelectedBoundingBox(mc.theWorld, event.target.getBlockPos());

        if (box == null) {
            return;
        }

        // Tiny expansion prevents z-fighting with the block surface.
        box = box.expand(0.0015D, 0.0015D, 0.0015D);

        double x = box.minX - mc.getRenderManager().viewerPosX;
        double y = box.minY - mc.getRenderManager().viewerPosY;
        double z = box.minZ - mc.getRenderManager().viewerPosZ;
        double X = box.maxX - mc.getRenderManager().viewerPosX;
        double Y = box.maxY - mc.getRenderManager().viewerPosY;
        double Z = box.maxZ - mc.getRenderManager().viewerPosZ;

        GlStateManager.pushMatrix();

        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.tryBlendFuncSeparate(
            GL11.GL_SRC_ALPHA,
            GL11.GL_ONE_MINUS_SRC_ALPHA,
            GL11.GL_ONE,
            GL11.GL_ZERO
        );
        GlStateManager.disableCull();
        GlStateManager.depthMask(false);
        GlStateManager.color(0.0F, 0.0F, 0.0F, OVERLAY_ALPHA);

        Tessellator tessellator = Tessellator.getInstance();
        WorldRenderer wr = tessellator.getWorldRenderer();

        wr.begin(GL11.GL_QUADS, DefaultVertexFormats.POSITION);

        // Bottom
        wr.pos(x, y, z).endVertex();
        wr.pos(X, y, z).endVertex();
        wr.pos(X, y, Z).endVertex();
        wr.pos(x, y, Z).endVertex();

        // Top
        wr.pos(x, Y, Z).endVertex();
        wr.pos(X, Y, Z).endVertex();
        wr.pos(X, Y, z).endVertex();
        wr.pos(x, Y, z).endVertex();

        // North
        wr.pos(x, y, z).endVertex();
        wr.pos(x, Y, z).endVertex();
        wr.pos(X, Y, z).endVertex();
        wr.pos(X, y, z).endVertex();

        // South
        wr.pos(X, y, Z).endVertex();
        wr.pos(X, Y, Z).endVertex();
        wr.pos(x, Y, Z).endVertex();
        wr.pos(x, y, Z).endVertex();

        // West
        wr.pos(x, y, Z).endVertex();
        wr.pos(x, Y, Z).endVertex();
        wr.pos(x, Y, z).endVertex();
        wr.pos(x, y, z).endVertex();

        // East
        wr.pos(X, y, z).endVertex();
        wr.pos(X, Y, z).endVertex();
        wr.pos(X, Y, Z).endVertex();
        wr.pos(X, y, Z).endVertex();

        tessellator.draw();

        GlStateManager.depthMask(true);
        GlStateManager.enableCull();
        GlStateManager.disableBlend();
        GlStateManager.enableTexture2D();
        GlStateManager.color(1.0F, 1.0F, 1.0F, 1.0F);

        GlStateManager.popMatrix();
    }
}
